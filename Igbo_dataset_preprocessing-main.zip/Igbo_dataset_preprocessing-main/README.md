# Igbo_dataset_preprocessing
Contains the code i used to process my igbo alphabet dataset.

Requirements
-> pip install opencv-python
=> pip install mysql-connector-python
=> pip install mysql
